import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';
import { PopoverPage } from '../about-popover/about-popover';

import { LivestreamPageRoutingModule } from './livestream-routing.module';

import { LivestreamPage } from './livestream.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    LivestreamPageRoutingModule
  ],
  declarations: [LivestreamPage, PopoverPage],
  entryComponents: [PopoverPage],
  bootstrap: [LivestreamPage]
})
export class LivestreamModule {}

