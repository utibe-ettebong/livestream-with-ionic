import { Component } from '@angular/core';
import { MenuController } from '@ionic/angular'

@Component({
  selector: 'app-livestream',
  templateUrl: './livestream.page.html',
  styleUrls: ['./livestream.page.scss'],
})
export class LivestreamPage {

  paneEnabled = true;
  constructor(private menuController: MenuController) { }

  ionviewWillWEnter() {
    this.menuController.enable(true, 'third');
    }
  
  ionViewwWillLeave() {
    this.paneEnabled = false;
  }

}
